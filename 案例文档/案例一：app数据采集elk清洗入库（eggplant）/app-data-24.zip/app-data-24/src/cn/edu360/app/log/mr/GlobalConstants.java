package cn.edu360.app.log.mr;

public class GlobalConstants {
	
	public static final String HEADER = "header";

}
