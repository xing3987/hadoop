package cn.edu360.test;

import java.util.Date;

public class TimeTest {
	
	public static void main(String[] args) {
		
		Date date2 = new Date(1502683439386L+38*24*60*60*1000L);
		System.out.println(date2);
		
	}

}
